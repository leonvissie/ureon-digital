# Ureon Digital Brand Asset Pack v2

Generated from the supplied final UD circular-gradient logo.

## Contents

- `source/ud-logo-master.png` — master PNG source
- `png/transparent/` — transparent logo PNGs from 16px to 1024px
- `png/dark-background/` — square dark-background PNGs from 16px to 1024px
- `app-icons/` — rounded-square 512x512 and 1024x1024 app icon variants
- `favicon/` — favicon PNGs and `.ico`
- `preview/asset-preview.png` — quick visual preview

## Recommended use

- Website header / brand mark: `png/transparent/ud-logo-transparent-512.png`
- Favicon: `favicon/favicon.ico`
- Future app icon: `app-icons/ud-app-icon-1024.png`
